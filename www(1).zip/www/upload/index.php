<?php
header("Location : https://www.google.com");
