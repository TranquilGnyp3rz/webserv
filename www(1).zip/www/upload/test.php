<?php
// header("Location : https://www.google.com");
while (1)
{
	
	sleep (5);
}